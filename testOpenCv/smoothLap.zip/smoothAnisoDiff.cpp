#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>

using namespace cv;
using namespace std;


void anisotropicDiffusion(Mat& img, Mat&dst, int num_iter, double delta_t, int kappa)
{
	// Variables
	//double delta;
	double ikappa = 1 / kappa;

	// argument for filter
	int ddepth = -1;

	// convert to grayscale             ~0.5ms
//	cvtColor(img, res, CV_BGR2GRAY);
	//res = img;

	// initialize filter outputs        ~2-3us
	Mat nablaN, nablaS, nablaW, nablaE, nablaNE, nablaSE, nablaSW, nablaNW;

	// further initializations          ~2-3us
	Mat cN, cS, cW, cE, cNE, cSE, cSW, cNW;

	//window for laplacian computation
	Mat hN = (Mat_<double>(3, 3) << 0,1,0, 0,-1,0, 0,0,0);
	Mat hS = (Mat_<double>(3, 3) << 0,0,0, 0,-1,0, 0,1,0);
	Mat hE = (Mat_<double>(3, 3) << 0,0,0, 0,-1,1, 0,0,0);
	Mat hW = (Mat_<double>(3, 3) << 0,0,0, 1,-1,0, 0,0,0);
	Mat hNE = (Mat_<double>(3, 3) << 0,0,1, 0,-1,0, 0,0,0);
	Mat hSE = (Mat_<double>(3, 3) << 0,0,0, 0,-1,0, 0,0,1);
	Mat hSW = (Mat_<double>(3, 3) << 0,0,0, 0,-1,0, 1,0,0);
	Mat hNW = (Mat_<double>(3, 3) << 1,0,0, 0,-1,0, 0,0,0);

	Mat res;
	// Anisotropic diffusion.           
	for (int i = 1; i <= num_iter; i++) // one iteration ~44ms
	{
		GaussianBlur(img, res, Size(3, 3), 1, 1);
		//medianBlur(img, res, 3);
		cout << res;
	//	img.copyTo(res);
		// filtering                ~5ms
		filter2D(res, nablaN, ddepth, hN);
		filter2D(res, nablaS, ddepth, hS);
		filter2D(res, nablaW, ddepth, hW);
		filter2D(res, nablaE, ddepth, hE);
		filter2D(res, nablaNE, ddepth, hNE);
		filter2D(res, nablaSE, ddepth, hSE);
		filter2D(res, nablaSW, ddepth, hSW);
		filter2D(res, nablaNW, ddepth, hNW);
	//	cout << nablaN;
		// Diffusion function       ~28ms
		cN = nablaN*ikappa;
		cN.mul(cN);
		cN = 1.0 / (1.0 + cN);

		cS = nablaS*ikappa;
		cS.mul(cS);
		cS = 1.0 / (1.0 + cN);

		cW = nablaW*ikappa;
		cW.mul(cW);
		cW = 1.0 / (1.0 + cW);

		cE = nablaE*ikappa;
		cE.mul(cE);
		cE = 1.0 / (1.0 + cE);

		cNE = nablaNE*ikappa;
		cNE.mul(cNE);
		cNE = 1.0 / (1.0 + cNE);

		cSE = nablaSE*ikappa;
		cSE.mul(cSE);
		cSE = 1.0 / (1.0 + cSE);

		cSW = nablaSW*ikappa;
		cSW.mul(cSW);
		cSW = 1.0 / (1.0 + cSW);

		cNW = nablaNW*ikappa;
		cNW.mul(cNW);
		cNW = 1.0 / (1.0 + cNW);

		// Discrete PDE solution.       ~11ms
		Mat shift(img.rows, img.cols, DataType<double>::type);
		  shift = delta_t * (cN.mul(nablaN)                                 
			+ cS.mul(nablaS)                               
			+ cW.mul(nablaW)                                
			+ cE.mul(nablaE)                              
			+ cNE.mul(nablaNE) * 0.5                        
			+ cSE.mul(nablaSE) * 0.5                       
			+ cSW.mul(nablaSW) * 0.5                        
			+ cNW.mul(nablaNW) * 0.5);
		img = img + shift;
		cout << shift;                    //+ (1 / (cv::pow(dd, 2)))*cNW.mul(nablaNW));
	}
	Mat C = (Mat_<double>(3, 3) << 0, -1, 0, -1, 5, -1, 0, -1, 0);
	dst = img;
}

int main(int argc, char** argv)
{

	int iteration;
	cout << " enter the number of iterations ::  " << endl;
	cin >> iteration;

	double intConst;
	cout << " enter the integration constant ::  " << endl;
	cin >> intConst;

	double edgeThre;
	cout << " enter the edge thyreshold value ::  " << endl;
	cin >> edgeThre;

	//create 2 empty windows
	namedWindow("Original Image", CV_WINDOW_AUTOSIZE);
	namedWindow("Smoothed Image", CV_WINDOW_AUTOSIZE);

	// Load an image from file
	Mat src = imread("Noise_Lines.tif", CV_LOAD_IMAGE_UNCHANGED);

	//show the loaded image
	imshow("Original Image", src);

	Mat dst;

	anisotropicDiffusion(src, dst, iteration, intConst, edgeThre);
	//make the "dst" image, black
	//dst = Mat::zeros(src.size(), src.type());
	//imwrite("TestData_4_med.jpg", dst);
	//copy the text to the "zBuffer"
//	cout << dst;
	//show the black image with the text
	imshow("Smoothed Image", dst);
	cout << " Anisotropic smoothing is done ::  " << endl;
	//wait for a key press infinitely
	waitKey(0);

	return 0;
}