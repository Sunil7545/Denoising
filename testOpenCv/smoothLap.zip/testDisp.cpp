#include "opencv2/highgui/highgui.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main(int argc, const char** argv)
{
	Mat img = imread("TestData_2.tif", CV_LOAD_IMAGE_UNCHANGED); //read the image data in the file "MyPic.JPG" and store it in 'img'

	if (img.empty()) //check whether the image is loaded or not
	{
		cout << "Error : Image cannot be loaded..!!" << endl;
		//system("pause"); //wait for a key press
		return -1;
	}
	int height = img.rows; 
	int width = img.cols;
	//int channel = img.ch;
	cout << " Height of the image: ";
	cout << height;
	cout << " Width of the image: ", width;
	cout << width;
	//cout << " number of chhanels in image: ", channel;

	namedWindow("InputImage", CV_WINDOW_AUTOSIZE); //create a window with the name "MyWindow"
	imshow("InputImage", img); //display the image which is stored in the 'img' in the "MyWindow" window

	waitKey(0); //wait infinite time for a keypress

	destroyWindow("InputImage"); //destroy the window with the name, "MyWindow"

	return 0;
}